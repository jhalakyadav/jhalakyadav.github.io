public class Matrix {

//	public static boolean checkMatrix(int[][] m) {
//		// TODO: Vervollständigen Sie den Code wie in der Aufgabenbeschreibung beschrieben
//		int n = m.length;
//
//		//nxn
//		for(int i = 0; i < n; i++){
//			if(m[i].length != n) return false;
//		}
//
//		//0 < m_ij <= n^2
//		for(int i = 0; i < n; i++){
//			for(int j = 0; j < m[i].length; j++){
//				if(m[i][j] <= 0 || m[i][j] > Math.pow(n, 2)) return false;
//			}
//		}
//
//		//unique elements
//		for(int i = 0; i < n; i++){
//			for(int j = 0; j < m[i].length; j++){
//				for(int k = 0; k < n; k++){
//					for(int h = 0; h < m[k].length; h++){
//						if(i != k && j != h && m[i][j] == m[k][h]) return false;
//					}
//				}
//			}
//		}
//
//		//Zeilensumme gleich
//		int[] row = new int[n];
//		for(int i = 0; i < n; i++){
//			for(int j = 0; j < m[i].length; j++){
//				row[i] += m[i][j];
//			}
//		}
//
//		for(int i = 0; i < n; i++){
//			if(row[0] != row[i]) return false;
//		}
//
//		//Spaltensumme gleich
//		int[] col = new int[n];
//		for(int i = 0; i < n; i++){
//			for(int j = 0; j < m[i].length; j++){
//				col[j] += m[i][j];
//			}
//		}
//
//		for(int i = 0; i < n; i++){
//			if(col[0] != col[i]) return false;
//		}
//
//		return true;
//	}

	///*Alternative
	public static boolean checkMatrix(int[][] m){
		int n = m.length;
		int[] row = new int[n];
		int[] col = new int[n];

		for(int i = 0; i < n; i++){
			if(m[i].length != n) return false;
			for(int j = 0; j < m[i].length; j++){
				if(m[i][j] <= 0 || m[i][j] > Math.pow(n, 2)) return false;
				row[i] += m[i][j];
				col[j] += m[i][j];
				for(int k = 0; k < n; k++){
					for(int h = 0; h < m[k].length; h++){
						if(i != k && j != h && m[i][j] == m[k][h]) return false;
					}
				}
			}
		}

		for(int i = 0; i < n; i++){
			if(row[0] != row[i]) return false;
			if(col[0] != col[i]) return false;
		}

		return true;
	}
	//*/

}
