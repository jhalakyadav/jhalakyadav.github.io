import java.util.Arrays;

public class ArrayUtil {

	public static void main(String[] args) {
		// zeroInsert
		System.out.println("Teilaufgabe 1:");
		System.out.println("zeroInsert([3, 4, 5]): " + Arrays.toString(zeroInsert(new int[] {3, 4, 5})));
		System.out.println("zeroInsert([3, 0, -5]): " + Arrays.toString(zeroInsert(new int[] {3, 0, -5})));
		System.out.println("zeroInsert([-3, 4, 6, 9, -8]): " + Arrays.toString(zeroInsert(new int[] {-3, 4, 6, 9, -8})));

		// tenFollows
		System.out.println("\nTeilaufgabe 2:");
		System.out.println("tenFollows([1, 2, 20], 0): " + tenFollows(new int[] {1, 2, 20}, 0));
		System.out.println("tenFollows([1, 2, 7, 20], 0): " + tenFollows(new int[] {1, 2, 7, 20}, 0));
		System.out.println("tenFollows([3, 30], 0): " + tenFollows(new int[] {3, 30}, 0));
		System.out.println("tenFollows([3], 0): " + tenFollows(new int[] {3}, 0));
		System.out.println("tenFollows([1, 2, 20, 5], 1): " + tenFollows(new int[] {1, 2, 20, 5}, 1));
		System.out.println("tenFollows([1, 2, 20, 5], 2): " + tenFollows(new int[] {1, 2, 20, 5}, 2));
	}

	public static int[] zeroInsert(int[] x) {
		// TODO: Vervollständigen Sie den Code wie in der Aufgabenbeschreibung beschrieben
		return help1(x, 0);
	}

	public static int[] help1(int[] x, int i){
		//Base Case
		if(i >= x.length - 1) return x;
		//Recursion
		if((x[i] < 0 && x[i+1] > 0) || (x[i] > 0 && x[i+1] < 0)){
			int[] res = new int[x.length + 1];
			for(int j = 0; j <= i; j++){
				res[j] = x[j];
			}
			res[i+1] = 0;
			for(int j = i+2; j < res.length; j++){
				res[j] = x[j-1];
			}
			return help1(res, i+2);
		}
		return help1(x, i+1);
	}

	public static boolean tenFollows(int[] x, int index) {
		// TODO: Vervollständigen Sie den Code wie in der Aufgabenbeschreibung beschrieben
		return help2(x, index);
	}

	public static boolean help2(int[] x, int i){
		//Base Case
		if(i >= x.length - 1) return false;
		//Recursion
		if(x[i]*10 == x[i+1]) return true;
		return help2(x, i+1);
	}

}
