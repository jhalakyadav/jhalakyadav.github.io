plugins {
    id("java")
    id("application")
}

repositories {
    mavenCentral()
}
