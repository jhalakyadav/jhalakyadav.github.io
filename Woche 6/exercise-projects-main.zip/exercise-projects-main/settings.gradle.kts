rootProject.name = "EProg2026"

file(".")
    .walkTopDown()
    .maxDepth(2)
    .filter { dir ->
        dir.isDirectory &&
                File(dir, "build.gradle.kts").exists()
    }
    .forEach { dir ->
        val projectPath = dir
            .relativeTo(file("."))
            .path
            .replace(File.separator, ":")

        include(":$projectPath")
    }