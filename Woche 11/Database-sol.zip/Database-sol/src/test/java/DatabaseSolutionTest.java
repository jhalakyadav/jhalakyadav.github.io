import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

public class DatabaseSolutionTest {

    @Test
    public void unchangedHealthStillPropagatesAcrossTheComponent() {
        Database database = new Database();
        ItemFactory factory = database.getItemFactory();
        Item first = factory.createItem(new Level(List.of(1)), 1, 20, 42);
        Item second = factory.createItem(new Level(List.of(2)), 2, 30, 80);
        Item third = factory.createItem(new Level(List.of(3)), 3, 40, 90);
        database.add(first);
        database.add(second);
        database.add(third);
        database.createLink(List.of(1, 2));
        database.createLink(List.of(2, 3));
        database.createLink(List.of(3, 1));

        assertEquals(80, second.getHealth());
        first.setHealth(42);

        assertEquals(42, first.getHealth());
        assertEquals(42, second.getHealth());
        assertEquals(42, third.getHealth());
    }

    @Test
    public void missingIdDoesNotPartiallyCreateLinks() {
        Database database = new Database();
        ItemFactory factory = database.getItemFactory();
        Item first = factory.createItem(new Level(List.of(1)), 1, 20, 10);
        Item second = factory.createItem(new Level(List.of(2)), 2, 30, 20);
        database.add(first);
        database.add(second);

        assertThrows(IllegalArgumentException.class,
                () -> database.createLink(List.of(1, 2, 99)));
        first.setHealth(30);

        assertEquals(20, second.getHealth());
    }

    @Test
    public void declassificationUsesTheLiveTargetAndIgnoresWrites() {
        Database database = new Database();
        ItemFactory factory = database.getItemFactory();
        Item target = factory.createItem(new Level(List.of(1)), 1, 20, 10);
        database.add(target);
        Item declassified = factory.createDeclass(new Level(List.of(2)), 2, 1);
        database.add(declassified);
        Item second = factory.createDeclass(new Level(List.of(3)), 3, 2);

        second.setHealth(50);
        assertEquals(10, target.getHealth());
        assertEquals(10, second.getHealth());

        target.setHealth(60);
        assertEquals(20, second.getAge());
        assertEquals(60, second.getHealth());
        assertEquals(3, second.getID());
    }

    @Test
    public void everyLevelInTheTargetChainMustBeChecked() {
        Database database = new Database();
        ItemFactory factory = database.getItemFactory();
        database.add(factory.createItem(new Level(List.of(1)), 1, 20, 10));
        database.add(factory.createDeclass(new Level(List.of(2)), 2, 1));
        database.add(factory.createDeclass(new Level(List.of(3)), 3, 2));

        assertThrows(IllegalArgumentException.class,
                () -> factory.createDeclass(new Level(List.of(2)), 4, 3));
        assertThrows(IllegalArgumentException.class,
                () -> factory.createDeclass(new Level(List.of(1)), 4, 3));
    }

    @Test
    public void distinctLargeLevelSumsDoNotBecomeRelatedThroughOverflow() {
        Database database = new Database();
        ItemFactory factory = database.getItemFactory();
        Level targetLevel = new Level(List.of(Integer.MAX_VALUE, Integer.MAX_VALUE, 2));
        database.add(factory.createItem(targetLevel, 1, 20, 10));

        assertNotNull(factory.createDeclass(new Level(List.of(0)), 2, 1));
    }

    @Test
    public void emptyAndRepeatedLinksDoNotAffectUnlinkedItems() {
        Database database = new Database();
        ItemFactory factory = database.getItemFactory();
        Item first = factory.createItem(new Level(List.of(1)), 1, 20, 10);
        Item second = factory.createItem(new Level(List.of(2)), 2, 30, 20);
        database.add(first);
        database.add(second);

        database.createLink(List.of());
        database.createLink(List.of(1, 1));
        first.setHealth(30);

        assertEquals(30, first.getHealth());
        assertEquals(20, second.getHealth());
    }
}
