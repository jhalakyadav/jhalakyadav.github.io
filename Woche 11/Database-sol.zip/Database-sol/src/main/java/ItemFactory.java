import java.util.List;

public class ItemFactory {

    private final Database database;

    ItemFactory(Database database) {
        this.database = database;
    }

    public Item createItem(Level level, int id, int age, int health) {
        return new Item(level, id, age, health);
    }

    public Item createDeclass(Level level, int id, int targetId) {
        Item target = this.database.getItem(targetId);
        Item current = target;
        int levelSum = this.getLevelSum(level);

        while (true) {
            if (this.getLevelSum(current.getLevel()) == levelSum) {
                throw new IllegalArgumentException("Related security level in target chain");
            }

            if (current instanceof DeclassifiedItem) {
                DeclassifiedItem declassified = (DeclassifiedItem) current;
                current = declassified.getTarget();
            } else {
                return new DeclassifiedItem(level, id, target);
            }
        }
    }

    private int getLevelSum(Level level) {
        List<Integer> points = level.getPoints();
        int sum = 0;

        for (int i = 0; i < points.size(); ++i) {
            sum = sum + points.get(i);
        }

        return sum;
    }
}
