import java.util.ArrayList;
import java.util.List;

public class Database {

    private List<Item> items = new ArrayList<>();
    private final ItemFactory factory = new ItemFactory(this);

    public Item getItem(int id) {
        for (int i = 0; i < this.items.size(); ++i) {
            Item current = this.items.get(i);
            if (current.getID() == id) {
                return current;
            }
        }

        throw new IllegalArgumentException("No item with ID " + id);
    }

    public void add(Item item) {
        this.items.add(item);
    }

    public List<Item> getItems() {
        return new ArrayList<>(this.items);
    }

    public ItemFactory getItemFactory() {
        return this.factory;
    }

    public void createLink(List<Integer> ids) {
        List<Item> linkedItems = new ArrayList<>();

        for (int i = 0; i < ids.size(); ++i) {
            Item current = this.getItem(ids.get(i));
            linkedItems.add(current);
        }

        for (int i = 0; i < linkedItems.size(); ++i) {
            Item current = linkedItems.get(i);

            for (int j = 0; j < linkedItems.size(); ++j) {
                Item next = linkedItems.get(j);
                current.addLink(next);
            }
        }
    }
}
