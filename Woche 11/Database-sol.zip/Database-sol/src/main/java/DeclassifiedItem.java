public class DeclassifiedItem extends Item {

    private Item target;

    public DeclassifiedItem(Level level, int id, Item target) {
        super(level, id, 0, 0);
        this.target = target;
    }

    @Override
    public int getAge() {
        return this.target.getAge();
    }

    @Override
    public int getHealth() {
        return this.target.getHealth();
    }

    @Override
    public void setHealth(int newHealth) {
    }

    @Override
    protected void updateHealth(int newHealth) {
    }

    Item getTarget() {
        return this.target;
    }
}
