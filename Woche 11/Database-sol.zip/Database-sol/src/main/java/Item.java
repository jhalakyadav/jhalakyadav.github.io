import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Item {

    private Level level;
    private int id;
    private int age;
    private int health;
    private List<Item> links = new ArrayList<>();

    public Item(Level level, int id, int age, int health) {
        this.level = level;
        this.id = id;
        this.age = age;
        this.health = health;
    }

    public Level getLevel() {
        return this.level;
    }

    public int getID() {
        return this.id;
    }

    public int getAge() {
        return this.age;
    }

    public int getHealth() {
        return this.health;
    }

    // Visit every linked item once, even if this item's health already equals newHealth.
    public void setHealth(int newHealth) {
        Set<Item> visited = new HashSet<>();
        List<Item> pending = new ArrayList<>();
        pending.add(this);

        for (int i = 0; i < pending.size(); ++i) {
            Item current = pending.get(i);
            if (!visited.add(current)) {
                continue;
            }

            current.updateHealth(newHealth);

            for (int j = 0; j < current.links.size(); ++j) {
                Item next = current.links.get(j);
                if (!visited.contains(next)) {
                    pending.add(next);
                }
            }
        }
    }

    protected void updateHealth(int newHealth) {
        this.health = newHealth;
    }

    void addLink(Item item) {
        if (!this.links.contains(item)) {
            this.links.add(item);
        }
    }
}
