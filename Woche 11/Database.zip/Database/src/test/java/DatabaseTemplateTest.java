import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

public class DatabaseTemplateTest {

    @Test
    public void lookupIsRestrictedToTheOwningDatabase() {
        Database first = new Database();
        Database second = new Database();
        Item item = first.getItemFactory().createItem(new Level(List.of(1)), 7, 20, 50);
        first.add(item);
        assertSame(item, first.getItem(7));
        assertThrows(IllegalArgumentException.class, () -> second.getItem(7));
    }

    @Test
    public void returnedListsDoNotExposeInternalStorage() {
        Database database = new Database();
        Item item = database.getItemFactory().createItem(new Level(List.of(1)), 7, 20, 50);
        database.add(item);
        database.getItems().clear();
        assertSame(item, database.getItem(7));

        java.util.ArrayList<Integer> points = new java.util.ArrayList<>(List.of(1, 2));
        Level level = new Level(points);
        points.clear();
        level.getPoints().clear();
        assertEquals(List.of(1, 2), level.getPoints());
    }
}
