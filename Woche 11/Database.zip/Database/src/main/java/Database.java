import java.util.ArrayList;
import java.util.List;

public class Database {

	private List<Item> items = new ArrayList<>();
	private final ItemFactory factory = new ItemFactory(this);

	public Item getItem(int id) {
		for (Item item : items) {
			if (item.getID() == id) {
				return item;
			}
		}
		throw new IllegalArgumentException("No item with ID " + id);
	}

	public void add(Item item) { 
		items.add(item); 
	}

	public List<Item> getItems() { 
		return new ArrayList<>(items);
	}

	public ItemFactory getItemFactory() { 
		return factory; 
	}
	
	public void createLink(List<Integer> ids) {
		// TODO
	}
}
