import java.util.List;

public class DatabaseMain {

    public static void main(String[] args) {
        Database database = new Database();
        ItemFactory factory = database.getItemFactory();
        Item first = factory.createItem(new Level(List.of(1)), 1, 20, 50);
        Item second = factory.createItem(new Level(List.of(2)), 2, 30, 80);
        database.add(first);
        database.add(second);

        database.createLink(List.of(1, 2));
        first.setHealth(42);
        System.out.println("Linked health: expected 42; actual " + second.getHealth());
    }
}
