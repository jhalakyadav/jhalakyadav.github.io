
public class ItemFactory {

	private final Database database;

	ItemFactory(Database database) {
		this.database = database;
	}

	public Item createItem(Level level, int id, int age, int health) { 
		return new Item(level, id, age, health); 
	}

	public Item createDeclass(Level level, int id, int targetId) {
		// TODO: Resolve targetId using database.getItem(targetId), then check the chain.
		return null;
	}
}
