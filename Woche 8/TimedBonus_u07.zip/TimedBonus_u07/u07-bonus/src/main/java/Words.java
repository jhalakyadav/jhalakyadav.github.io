public class Words {

	public static String getWord(char[][] chars) {
		// Ungültige Eingaben (null sind häufige Edge Cases)
		if(chars == null) return "Ungueltig";
		int n = chars.length;
		if(n < 1) return "Ungueltig";
		if(chars[0] == null) return "Ungueltig";
		int m = chars[0].length;
		if(m < 1) return "Ungueltig";
		for(int i = 0; i < n; i++){
			if(chars[i] == null || chars[i].length != m) return "Ungueltig";
		}

		//Funktionalität: Iterativ
		String res = "";

		int top = 0;
		int bottom = n - 1;
		int left = 0;
		int right = m - 1;

		while (top <= bottom && left <= right) {
			//obere Zeile
			for (int j = left; j <= right; j++) {
				res += chars[top][j];
			}
			top++;

			//rechte Spalte
			for (int i = top; i <= bottom; i++) {
				res += chars[i][right];
			}
			right--;

			//untere Zeile
			if (top <= bottom) {
				for (int j = right; j >= left; j--) {
					res += chars[bottom][j];
				}
				bottom--;
			}

			//linke Spalte
			if (left <= right) {
				for (int i = bottom; i >= top; i--) {
					res += chars[i][left];
				}
				left++;
			}
		}

		//return res;

		//Funktionalität: Rekursiv
		return help(chars);
	}

	public static String help(char[][] chars){
		String res = "";
		int n = chars.length;
		//Base Cases
		// Array ist leer
		if(n == 0) return "";
		int m = chars[0].length;
		if(m == 0) return "";
		if(n == 1){
			//Array hat 1 Zeile
			for(int i = 0; i < m; i++){
				res += chars[0][i];
			}
			return res;
		}else if(m == 1){
			//Array hat 1 Spalte
			for(int i = 0; i < n; i++){
				res += chars[i][0];
			}
			return res;
		}
		//Recursion
		//obere Zeile
		for(int i = 0; i < m; i++){
			res += chars[0][i];
		}

		//Rechte Spalte
		for(int i = 1; i < n; i++){
			res += chars[i][m-1];
		}

		//Untere Zeile
		for(int i = m-2; i >= 0; i--){
			res += chars[n-1][i];
		}

		//Linke Spalte
		for(int i = n-2; i > 0; i--){
			res += chars[i][0];
		}

		//Inneres array
		char[][] c = new char[n-2][m-2];
		int k = 0;
		for(int i = 1; i < n-1; i++){
			int h = 0;
			for(int j = 1; j < m-1; j++){
				c[k][h] = chars[i][j];
				h++;
			}
			k++;
		}

		return res + help(c);
	}
}
