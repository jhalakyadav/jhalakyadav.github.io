public class Main {

	public static void main(String[] args) {
		char[][] hello = new char[][] {
			{'H', 'e', 'l', 'l'},
			{'c', 'o', 'm', 'o'},
			{'l', ')', 'e', ' '},
			{'e', ':', ' ', 'a'},
			{'w', ' ', 'd', 'n'}
		};

		String resultHello = Words.getWord(hello);

		System.out.println(resultHello + " --- expected: \"Hello and welcome :)\"");

		char[][] exam = new char[][] {
			{'E', 'P', 'r'},
			{'x', 'a', 'o'},
			{'E', 'm', 'g'},
			{' ', '-', ' '}
		};

		String resultExam = Words.getWord(exam);

		System.out.println(resultExam + " --- expected: \"EProg - Exam\"");

		char[][] luck = new char[][] {
			{'G', 'o', 'o', 'd', ' '},
			{'!', 'k', 'c', 'u', 'l'}
		};

		String resultLuck = Words.getWord(luck);

		System.out.println(resultLuck + " --- expected: \"Good luck!\"");
	}

}
