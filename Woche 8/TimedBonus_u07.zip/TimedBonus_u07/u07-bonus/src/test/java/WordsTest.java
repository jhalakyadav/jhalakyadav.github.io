import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class WordsTest {

	@Test
	public void testGetWord1() {
		char[][] chars = new char[][] {
			{'n', 'i', 'c'},
			{' ', 'l', 'e', 'h'},
			{'g', 'r', 'i', 't'},
			{'i', 'e', 'd', 'g'},
			{'t', 'l', 'e', 'u'}
		};

		String result = Words.getWord(chars);

		assertEquals("Ungueltig", result);
	}

	@Test
	public void testGetWord2() {
		char[][] chars = new char[][] {
			{'a', 'u', 'c', 'h'},
			{'a', 'l', ' '},
			{'v', 'i', 'n'},
			{' ', 'd', 'i'},
			{'t', 'h', 'c'}
		};

		String result = Words.getWord(chars);

		assertEquals("Ungueltig", result);
	}

	@Test
	public void testGetWord3() {
		char[][] chars = new char[][] {
			{'H', 'e', 'l', 'l'},
			{'c', 'o', 'm', 'o'},
			{'l', ')', 'e', ' '},
			{'e', ':', ' ', 'a'},
			{'w', ' ', 'd', 'n'}
		};

		String result = Words.getWord(chars);

		assertEquals("Hello and welcome :)", result);
	}

	@Test
	public void testGetWord4() {
		char[][] chars = new char[][] {
			{'E', 'P', 'r'},
			{'x', 'a', 'o'},
			{'E', 'm', 'g'},
			{' ', '-', ' '}
		};

		String result = Words.getWord(chars);

		assertEquals("EProg - Exam", result);
	}

	@Test
	public void testGetWord5() {
		char[][] chars = new char[][] {
			{'G', 'o', 'o', 'd', ' '},
			{'!', 'k', 'c', 'u', 'l'}
		};

		String result = Words.getWord(chars);

		assertEquals("Good luck!", result);
	}

	@Test
	public void test01_01() {
		// n < 1
		char[][] input = new char[0][3];

		assertEquals("Ungueltig", Words.getWord(input));
	}

	@Test
	public void test01_02() {
		// m < 1
		char[][] input = new char[3][0];

		assertEquals("Ungueltig", Words.getWord(input));
	}

	@Test
	public void test01_03() {
		// null input
		char[][] input = null;

		assertEquals("Ungueltig", Words.getWord(input));
	}

	@Test
	public void test01_04() {
		// null row
		char[][] input = {
				{'a', 'b'},
				null,
				{'c', 'd'}
		};

		assertEquals("Ungueltig", Words.getWord(input));
	}

	@Test
	public void test01_05() {
		// not nxm
		char[][] input = {
				{'a', 'b'},
				{'c', 'd', 'e'},
				{'f', 'g', 'h'}
		};

		assertEquals("Ungueltig", Words.getWord(input));
	}

	@Test
	public void test01_06() {
		// not nxm
		char[][] input = {
				{'a', 'b', 'c'},
				{'c', 'd'},
				{'f', 'g'}
		};

		assertEquals("Ungueltig", Words.getWord(input));
	}

	@Test
	public void test02_01() {
		// 1x1
		char[][] input = {
				{'!'}
		};
		assertEquals("!", Words.getWord(input));
	}

	@Test
	public void test02_02() {
		// 1x4
		char[][] input = {
				{'J', 'a', 'v', 'a'}
		};
		assertEquals("Java", Words.getWord(input));
	}

	@Test
	public void test02_03() {
		// 4x1
		char[][] input = {
				{'E'},
				{'T'},
				{'H'},
				{'!'}
		};
		assertEquals("ETH!", Words.getWord(input));
	}

	@Test
	public void test02_04() {
		// 3x3
		char[][] input = {
				{'s', 'p', 'i'},
				{'n', 'g', 'r'},
				{'i', 'l', 'a'}
		};
		assertEquals("spiraling", Words.getWord(input));
	}

	@Test
	public void test02_05() {
		// 4x4
		char[][] input = {
				{'H', 'e', 'l', 'l'},
				{'!', 'Y', 'E', 'o'},
				{'!', 'H', 'A', 'W'},
				{'d', 'l', 'r', 'o'}
		};
		assertEquals("HelloWorld!!YEAH", Words.getWord(input));
	}

	@Test
	public void test02_06() {
		// 3x5
		char[][] input = {
				{'E', 'T', 'H', 'Z', 'u'},
				{'a', 'm', '2', '6', 'r'},
				{'x', 'E', 'h', 'c', 'i'}
		};
		assertEquals("ETHZurichExam26", Words.getWord(input));
	}

	@Test
	public void test02_07() {
		// 3x6
		char[][] input = {
				{'H', 'e', 'l', 'l', 'o', ' '},
				{'c', 'o', 'm', 'e', '!', 'a'},
				{'l', 'e', 'w', ' ', 'd', 'n'}
		};
		assertEquals("Hello and welcome!", Words.getWord(input));
	}

	@Test
	public void test02_08() {
		// 3x2
		char[][] input = {
				{'s', 'p'},
				{'l', 'i'},
				{'a', 'r'}
		};
		assertEquals("spiral", Words.getWord(input));
	}

	@Test
	public void test02_09() {
		// 5x3
		char[][] input = {
				{'W', 'o', 'r'},
				{'e', '!', 't'},
				{'k', 'O', 's'},
				{'c', 'K', 'c'},
				{'e', 'n', 'h'}
		};
		assertEquals("Wortschnecke!OK", Words.getWord(input));
	}

	@Test
	public void test02_10() {
		// 4x6
		char[][] input = {
				{'T', 'h', 'e', ' ', 'q', 'u'},
				{' ', 'f', 'o', 'x', ' ', 'i'},
				{'n', 'p', 'm', 'u', 'j', 'c'},
				{'w', 'o', 'r', 'b', ' ', 'k'}
		};
		assertEquals("The quick brown fox jump", Words.getWord(input));
	}

	@Test
	public void test02_11() {
		// 4x7
		char[][] input = {
				{'T', 'h', 'e', ' ', 'q', 'u', 'i'},
				{'o', 'x', ' ', 'j', 'u', 'm', 'c'},
				{'f', 'v', 'o', ' ', 's', 'p', 'k'},
				{' ', 'n', 'w', 'o', 'r', 'b', ' '}
		};
		assertEquals("The quick brown fox jumps ov", Words.getWord(input));
	}

	@Test
	public void test02_12() {
		// 4x3
		char[][] input = {
				{'H', 'e', 'l'},
				{'d', '!', 'l'},
				{'l', '!', 'o'},
				{'r', 'o', 'W'}
		};
		assertEquals("HelloWorld!!", Words.getWord(input));
	}

	@Test
	public void test02_13() {
		// 4x2
		char[][] input = {
				{'J', 'a'},
				{'!', 'v'},
				{'H', 'a'},
				{'T', 'E'}
		};
		assertEquals("JavaETH!", Words.getWord(input));
	}

	@Test
	public void test02_14() {
		// 24x37
		char[][] input = {
				{'L', 'o', 'r', 'e', 'm', ' ', 'i', 'p', 's', 'u', 'm', ' ', 'd', 'o', 'l', 'o', 'r', ' ', 's', 'i', 't', ' ', 'a', 'm', 'e', 't', ',', ' ', 'c', 'o', 'n', 's', 'e', 'c', 't', 'e', 't'},
				{'l', 'i', 'q', 'u', 'a', '.', ' ', 'U', 't', ' ', 'e', 'n', 'i', 'm', ' ', 'a', 'd', ' ', 'm', 'i', 'n', 'i', 'm', ' ', 'v', 'e', 'n', 'i', 'a', 'm', ',', ' ', 'q', 'u', 'i', 's', 'u'},
				{'a', 'u', 'a', 't', '.', ' ', 'D', 'u', 'i', 's', ' ', 'a', 'u', 't', 'e', ' ', 'i', 'r', 'u', 'r', 'e', ' ', 'd', 'o', 'l', 'o', 'r', ' ', 'i', 'n', ' ', 'r', 'e', 'p', 'r', ' ', 'r'},
				{' ', 'q', 'a', 't', 'u', 'r', '.', ' ', 'E', 'x', 'c', 'e', 'p', 't', 'e', 'u', 'r', ' ', 's', 'i', 'n', 't', ' ', 'o', 'c', 'c', 'a', 'e', 'c', 'a', 't', ' ', 'c', 'u', 'e', 'n', ' '},
				{'a', 'e', 'i', 't', ' ', 'a', 'n', 'i', 'm', ' ', 'i', 'd', ' ', 'e', 's', 't', ' ', 'l', 'a', 'b', 'o', 'r', 'u', 'm', '.', 'L', 'o', 'r', 'e', 'm', ' ', 'i', 'p', 'p', 'h', 'o', 'a'},
				{'n', 's', 'r', 'i', 'e', 'i', 'u', 's', 'm', 'o', 'd', ' ', 't', 'e', 'm', 'p', 'o', 'r', ' ', 'i', 'n', 'c', 'i', 'd', 'i', 'd', 'u', 'n', 't', ' ', 'u', 't', 's', 'i', 'e', 's', 'd'},
				{'g', 'n', 'a', 'l', ' ', 'e', 'n', 'i', 'a', 'm', ',', ' ', 'q', 'u', 'i', 's', ' ', 'n', 'o', 's', 't', 'r', 'u', 'd', ' ', 'e', 'x', 'e', 'r', 'c', 'i', ' ', 'u', 'd', 'n', 't', 'i'},
				{'a', 'o', 'p', 'l', 'o', 'v', ' ', 'c', 'o', 'm', 'm', 'o', 'd', 'o', ' ', 'c', 'o', 'n', 's', 'e', 'q', 'u', 'a', 't', '.', ' ', 'D', 'u', 'i', 's', 't', 'l', 'm', 'a', 'd', 'r', 'p'},
				{'m', 'c', ' ', 'o', 'd', ' ', 'a', 'v', 'o', 'l', 'u', 'p', 't', 'a', 't', 'e', ' ', 'v', 'e', 'l', 'i', 't', ' ', 'e', 's', 's', 'e', ' ', 'c', ' ', 'a', 'a', ' ', 't', 'e', 'u', 'i'},
				{' ', ' ', 'a', 'm', ' ', 'm', 'e', ' ', 'i', 'a', 't', 'u', 'r', '.', ' ', 'E', 'x', 'c', 'e', 'p', 't', 'e', 'u', 'r', ' ', 's', 'i', 'n', 'i', 'a', 't', 'b', 'd', 'a', 'r', 'd', 's'},
				{'e', 'o', 'l', ' ', 'd', 'i', ' ', 'n', 'r', 'r', 'o', 'i', 'd', 'e', 'n', 't', ',', ' ', 's', 'u', 'n', 't', ' ', 'i', 'n', ' ', 'c', 't', 'l', 'u', 'i', 'o', 'o', 't', 'i', ' ', 'c'},
				{'r', 'd', 'l', 't', 'e', 'n', 'x', 'i', 'a', 'p', 'e', 'r', 'u', 'n', 't', ' ', 'm', 'o', 'l', 'l', 'i', 't', ' ', 'a', 'n', 'i', 'u', ' ', 'l', 't', 'o', 'r', 'l', ' ', 't', 'e', 'i'},
				{'o', 'o', 'u', 'n', 's', 'i', 'e', ' ', 'p', ' ', 's', 'u', 'r', 'o', 'b', 'a', 'l', ' ', 't', 's', 'e', ' ', 'd', 'i', ' ', 'm', 'l', 'o', 'u', 'e', 'n', 'e', 'o', 'n', ' ', 'x', 'n'},
				{'l', 'm', 'n', 'u', ' ', 'm', ' ', 't', ' ', 'n', 'e', 'd', ' ', 'a', 'i', 'c', 'i', 'f', 'f', 'o', ' ', 'i', 'u', 'q', ' ', 'a', 'p', 'c', 'm', ' ', ' ', ' ', 'r', 'o', 'i', 'e', 'g'},
				{'o', 'm', ' ', 'r', ',', ' ', 'p', 'i', 'a', 'o', 'n', ' ', 't', 'a', 't', 'a', 'd', 'i', 'p', 'u', 'c', ' ', 't', 'a', 'c', 'e', 'a', 'c', ' ', 'i', 'u', 'e', ' ', 'n', 'n', 'r', ' '},
				{'d', 'o', 't', 'e', 't', 'd', 'i', 'r', 'l', 'l', 'u', 'n', ' ', 't', 'a', 'i', 'g', 'u', 'f', ' ', 'u', 'e', ' ', 'e', 'r', 'o', 'l', 'o', 'd', 'r', 'l', 't', 's', ' ', ' ', 'c', 'e'},
				{' ', 'c', 'a', 's', 'i', 'a', 'u', 'e', 'd', 'n', 'e', 'h', 'e', 'r', 'p', 'e', 'r', ' ', 'n', 'i', ' ', 'r', 'o', 'l', 'o', 'd', ' ', 'e', 'r', 'u', 'l', ' ', 'i', 'p', 'v', 'i', 'l'},
				{'t', ' ', 'i', 'e', 'l', ' ', 'q', 'i', 'l', 'a', ' ', 't', 'u', ' ', 'i', 's', 'i', 'n', ' ', 's', 'i', 'r', 'o', 'b', 'a', 'l', ' ', 'o', 'c', 'm', 'a', 'd', 't', 'r', 'o', 't', 'i'},
				{'e', 'a', 'g', 'd', 'e', 'm', 'i', 'n', 'e', ' ', 't', 'U', ' ', '.', 'a', 'u', 'q', 'i', 'l', 'a', ' ', 'a', 'n', 'g', 'a', 'm', ' ', 'e', 'r', 'o', 'l', 'o', ' ', 'o', 'l', 'a', 't'},
				{' ', 'e', 'u', ' ', ' ', 'g', 'n', 'i', 'c', 's', 'i', 'p', 'i', 'd', 'a', ' ', 'r', 'u', 't', 'e', 't', 'c', 'e', 's', 'n', 'o', 'c', ' ', ',', 't', 'e', 'm', 'a', 'i', 'u', 't', ','},
				{'e', ' ', 'f', 'a', 'i', 'c', 'i', 'f', 'f', 'o', ' ', 'i', 'u', 'q', ' ', 'a', 'p', 'l', 'u', 'c', ' ', 'n', 'i', ' ', 't', 'n', 'u', 's', ' ', ',', 't', 'n', 'e', 'd', 'p', 'i', ' '},
				{'r', 'x', ' ', 'u', 'e', ' ', 'e', 'r', 'o', 'l', 'o', 'd', ' ', 'm', 'u', 'l', 'l', 'i', 'c', ' ', 'e', 's', 's', 'e', ' ', 't', 'i', 'l', 'e', 'v', ' ', 'e', 't', 'a', 't', 'o', 's'},
				{'o', 'e', ' ', 'p', 'i', 'u', 'q', 'i', 'l', 'a', ' ', 't', 'u', ' ', 'i', 's', 'i', 'n', ' ', 's', 'i', 'r', 'o', 'b', 'a', 'l', ' ', 'o', 'c', 'm', 'a', 'l', 'l', 'u', ' ', 'n', 'e'},
				{'b', 'a', 'l', ' ', 't', 'u', ' ', 't', 'n', 'u', 'd', 'i', 'd', 'i', 'c', 'n', 'i', ' ', 'r', 'o', 'p', 'm', 'e', 't', ' ', 'd', 'o', 'm', 's', 'u', 'i', 'e', ' ', 'o', 'd', ' ', 'd'}
		};
		assertEquals(
				"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor i" +
						"ncididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostru" +
						"d exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aut" +
						"e irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat n" +
						"ulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui" +
						" officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consect" +
						"etur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna" +
						" aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi" +
						" ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in v" +
						"oluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occae" +
						"cat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id es" +
						"t laboru",
				Words.getWord(input));
	}

}
