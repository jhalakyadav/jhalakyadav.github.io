import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class WordsTest {

	@Test
	public void testGetWord1() {
		char[][] chars = new char[][] {
			{'n', 'i', 'c'},
			{' ', 'l', 'e', 'h'},
			{'g', 'r', 'i', 't'},
			{'i', 'e', 'd', 'g'},
			{'t', 'l', 'e', 'u'}
		};

		String result = Words.getWord(chars);

		assertEquals("Ungueltig", result);
	}

	@Test
	public void testGetWord2() {
		char[][] chars = new char[][] {
			{'a', 'u', 'c', 'h'},
			{'a', 'l', ' '},
			{'v', 'i', 'n'},
			{' ', 'd', 'i'},
			{'t', 'h', 'c'}
		};

		String result = Words.getWord(chars);

		assertEquals("Ungueltig", result);
	}

	@Test
	public void testGetWord3() {
		char[][] chars = new char[][] {
			{'H', 'e', 'l', 'l'},
			{'c', 'o', 'm', 'o'},
			{'l', ')', 'e', ' '},
			{'e', ':', ' ', 'a'},
			{'w', ' ', 'd', 'n'}
		};

		String result = Words.getWord(chars);

		assertEquals("Hello and welcome :)", result);
	}

	@Test
	public void testGetWord4() {
		char[][] chars = new char[][] {
			{'E', 'P', 'r'},
			{'x', 'a', 'o'},
			{'E', 'm', 'g'},
			{' ', '-', ' '}
		};

		String result = Words.getWord(chars);

		assertEquals("EProg - Exam", result);
	}

	@Test
	public void testGetWord5() {
		char[][] chars = new char[][] {
			{'G', 'o', 'o', 'd', ' '},
			{'!', 'k', 'c', 'u', 'l'}
		};

		String result = Words.getWord(chars);

		assertEquals("Good luck!", result);
	}

}
