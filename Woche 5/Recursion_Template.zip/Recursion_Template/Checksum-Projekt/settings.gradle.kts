rootProject.name = "Checksum"
