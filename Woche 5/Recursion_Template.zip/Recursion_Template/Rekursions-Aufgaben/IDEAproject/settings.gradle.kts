rootProject.name = "Rekursions-Aufgaben"
